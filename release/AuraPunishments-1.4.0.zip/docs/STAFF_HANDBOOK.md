# AuraPunishments 1.2.0 - Staff Handbook

## Entering text (1.2.0)

You never type into chat for the plugin any more. When a button needs text (a reason, a note, evidence, a name, a duration) a **window**
opens with a text box: write your answer, press **Submit**, or **Cancel** to change nothing. If it is too short or too long the window
re-opens with the problem shown and your text kept. Nobody else can see what you write.

## What's new in 1.1.0 (staff)

**Warnings.** Issue a warning from `/punish <player>` -> *Issue Warning* or `/ap warn <player> <reason>`. The player gets a chat message, a title (`OFFICIAL WARNING`), a sound and (if enabled) an action-bar line. If they are offline they get it, in order, at their next login. A warning never needs owner review and never jails, mutes or bans anyone by itself. The **Warnings** button on a profile (or `/ap warnings <player>`) lists each warning, whether the player saw it, and whether any later action was taken; a red *REPEAT WARNINGS* flag means the player reached the repeat threshold (default 3 in 30 days) - it is a prompt for *you* to consider a case, nothing more.

**Quick mutes / bans.** They still take effect immediately. A mute, ban or IP ban also goes to the owner team for review:

* You can follow it under *My punishments under review* (dashboard) or `/ap review mine`.
* Add supporting evidence from the review screen (*Add evidence*). You get reminders until you do; the punishment stays in force either way.
* A reviewer may ask you to explain - you will get an in-game message.
* A reviewer may uphold, shorten, reverse or refer it. You cannot review your own punishment.
* Reviews are about quality control, not about waiting for approval: do not wait for a review before acting on a real emergency.

**Emergency vs direct vs judicial.** Every punishment is labelled *Routine Warning*, *Emergency Quick Punishment*, *Direct Punishment*, *Emergency Protective Action* or *Judicial Sentence* in the GUI and logs. Use the hearing process (cases + custody) for normal disciplinary work; quick bans and direct punishments are for serious, proven situations.

**Defendants are told.** When you detain someone, they receive the case number, the alleged offense, your case description and the hearing instructions, plus a clear statement that this is not a finding of guilt. Keep case descriptions factual and free of private information - the defendant sees them.

**Other.** `/ap export <case>` saves a summary (if you hold `aurapunishments.export`); the case screen has *CoreProtect lookup* and *Appeal ticket* buttons if you hold those nodes.

For every Aurehaven staff member. What you can do depends on your rank's permissions ([PERMISSIONS.md](PERMISSIONS.md));
buttons you may not use are shown **locked** (grey, "Locked - not available to you") or hidden, depending on server config.
Showing a button never grants it: the server re-checks your authority every time you act.

## 1. The big picture

```
Minor / moderate offense                       Major offense, proven beyond reasonable doubt
        |                                                   |
   Create CASE  (evidence)                      DIRECT PUNISHMENT (evidence + justification)
        |                                         - the exception, not the normal workflow
   Pretrial detention (optional, JailReloaded; 48h review limit)
        |
   Awaiting trial -> hearing in Discord (judge: the owner) -> VERDICT -> SENTENCE
```

Pretrial detention is **not** a punishment and **not** a verdict. Nobody is held indefinitely: every detention has a
review deadline (default 48h) and is released automatically if nobody decides.

## 2. `/punish <player>`

Opens that player's screen directly (online players and anyone who has joined before - names are verified, never guessed;
if two players ever used the same name you must use their UUID). You cannot open yourself, and you cannot act on staff of
equal or higher rank.

```
 Row 1  [Create Case] [View Cases] [Submit Evidence] [Pretrial Detention] [Jail Status] [History] [Staff Notes]
 Row 2  [Warning] [Kick] [Mute] [Ban] [IP Ban] [Direct Punishment] [Emergency Action]
 Row 3  [Judicial Review]  [Release / Revoke Punishment]
 Below  the player's open cases (click to open)       Top: head, online status, active punishments, custody, counts
```

Other commands: `/punishments` (your dashboard), `/ap help`, `/ap case <id>`, `/ap cases`, `/ap history <player>`,
`/ap judge`, and command-line equivalents `/ap warn|kick|mute|ban|ipban|unmute|unban ...` (same rules as the GUI).

**Typing text:** when a button needs text (reason, description, evidence, note) the GUI closes and asks you to **type in
chat**. Your line is captured privately (nobody else sees it). Type `cancel` to abort. You have 90 seconds.

> **1.3.1:** on servers where the judicial system is off but the **case workflow** is on, you still *create a case* (this section), but there is no court: after the case exists, press **Punish** on the case screen to warn, kick, mute, ban, IP-ban or jail. The punishment is final at once, linked to the case, and the case stays open until you close it. See [WORKFLOW_CASEWORK.md](WORKFLOW_CASEWORK.md). The sections about pretrial detention, trials and verdicts do not apply there.

## 3. Create a case (the normal path)

1. `/punish <player>` -> **Create Case**.
2. **Offense** - pick the category (harassment, griefing, ...). The default severity comes with it; click **Severity** to change.
3. **Incident description** - what happened (at least 10 characters).
4. **Contextual notes** - optional.
5. **Evidence** - add at least what the offense requires (harassment, griefing, theft: 1). Pick the type (screenshot, video,
   chat log, **CoreProtect** lookup, server log, written report, anti-cheat alert, link, other), then type/paste the
   reference. Links must start with `http(s)://`. Written reports need 30+ characters.
6. **Submit Case.** You are recorded as the **prosecutor**. A duplicate open case for the same player and offense within
   10 minutes is refused (add evidence/notes to the existing case instead).

*Trainees* use the same screen to **report an incident**: it creates an ordinary case, but only you and the judge can see
it and you cannot start detention.

## 4. Evidence and notes

* **Submit Evidence** (from the player screen or inside a case) - evidence is **never deleted**. To fix a mistake use
  **Right-click: void** (reason required) or **Shift + Right-click: correct** (voids and replaces). Both are audited.
* **Staff Notes** - private notes on a case or on the player. Sensitive notes need extra permission. Notes are voided, not deleted.
* Left-click an evidence item to get a clickable link / copyable reference in chat.

## 5. Pretrial detention

Use it when the player should be held until a trial (for example, to prevent evidence tampering or repeat offenses).

1. **Pretrial Detention** on the player screen (or the **Custody** button inside the case) -> choose the case -> confirm.
2. JailReloaded imprisons the player. If JailReloaded cannot do it you are told **why** and nothing is recorded as done.
3. The case shows the review deadline. Staff with custody alerts are warned 12h and 1h before the deadline, and every
   hour once overdue. If nobody decides, the player is **released automatically** 12h after the deadline.
4. **Release** (Custody button or Jail Status) needs a reason, which is recorded. A judge can **extend** the deadline (twice, 24h each).

Do **not** use JailReloaded's `/unjail` for these prisoners; it is blocked with a message naming the case. Release through
the case so the record stays correct.

An offline player is registered with JailReloaded and placed in jail when they next log in; releasing an offline
prisoner completes at their next login ("release accepted").

## 6. Preparing the prosecution

Open the case (`/ap case 12`, `/ap cases`, or the player's open-case list):

* **Change status** - *Under Investigation*, *Awaiting Trial*, ... only valid next steps are enabled.
* **Schedule trial** - type `yyyy-MM-dd HH:mm` (server time) or a delay like `2d`.
* **Hearing reference** - the Discord voice channel name or link.
* **Edit details**, **Reassign prosecutor**, add evidence/notes. Everything is versioned: if someone else changed the case
  while you were looking, your change is refused and you are asked to reopen it (nothing is overwritten).

The hearing itself happens in a private Discord voice call: judge (owner), you as prosecutor, the accused speaking for
themselves, optional staff advisers. The judge records the verdict in the GUI ([Judicial handbook](JUDICIAL_HANDBOOK.md)).

## 7. Quick punishments (within your authority)

Warning / Kick / Mute / Ban / IP Ban -> choose the duration (anything above **your** limit is locked), enter the reason,
add evidence where required (bans and IP bans by default), **Continue**, confirm. Bans and IP bans also ask you to type the
player's name to confirm. Notes:

* **Kick** needs the player online. A **warning** to an offline player is shown when they next log in.
* A player can have only one active mute and one active ban at a time.
* Command line: `/ap mute Steve 30m Spamming global chat`, `/ap ban Steve 7d Cheating -e https://link`.
* Revoke with **Release / Revoke Punishment** or `/ap unmute|unban <player> <reason>` (a reason is always required). You can
  revoke punishments you issued yourself; senior staff can revoke any.

## 8. Direct punishment (major offenses only)

For serious, **proven** misconduct (severe cheating, exploitation, malicious attacks). It skips the hearing, so the screen
will not let you continue until **all** of these are done:

1. a *direct-eligible* major offense (only those appear);
2. severity MAJOR or SEVERE;
3. the punishment (mute, ban, IP ban - within your limit; permanent needs its own permission);
4. a **detailed description**;
5. **why bypassing the hearing is justified**;
6. the required **evidence** (usually 2 items);
7. confirmation (bans: type the player's name).

It creates a case marked *Direct Punishment Issued* with the evidence and justification attached, and alerts senior staff
(and Discord). It can be appealed and reviewed like any other outcome. **If in doubt, open a case.**

## 9. Emergency actions

For an *urgent threat in progress* (mass griefing, abuse flooding chat), staff with the separate emergency permission can
apply a **temporary mute or ban (max 24h)** immediately. A reason is mandatory, senior staff are alerted, and it **expires
by itself** unless a senior reviews it and replaces it with a proper punishment. Open the case it created to follow up.

## 10. History

**Punishment History** (or `/ap history <player>`) shows every case, finding and acquittal, and every punishment including
revoked and reversed ones. Acquittals, dismissals and overturned findings are shown as such and **never** count against the
player when a later sentence is recommended.

## 11. Things that are refused (and why)

| Message | Meaning |
|---|---|
| "You do not have permission..." | The node is missing; ask an admin if you should have it. |
| "...equal or higher staff authority" / "immune" | Hierarchy protection. |
| "...exceeds your limit... (your maximum: 1h)" | Duration tier. |
| "...requires at least N evidence reference(s)" | Add evidence first. |
| "This case was changed by someone else" | Reopen the case; your edit was not applied. |
| "JailReloaded is not available..." | The jail plugin is down/incompatible; nothing was changed. Tell an admin. |
| "Still working on your previous action" | Wait a moment; duplicate clicks are ignored on purpose. |


---

## 1.3.0: when your server has the judicial system switched off

Punishments are final the moment you issue them, and you will not see Create Case, Pretrial Detention, Direct Punishment or Judicial Review. You can still add **evidence** and a **staff note** while issuing a punishment, and afterwards from the history screen (click the punishment). **Jail** is an ordinary punishment (`/punish <player>` -> Issue Jail, `/ap jail`, release with `/ap unjail`). **Appeals** come from Discord Ticket Tool: record them on the punishment and reference the ticket. Full guide: [WORKFLOW_NO_JUDICIAL.md](WORKFLOW_NO_JUDICIAL.md), [JAIL.md](JAIL.md), [APPEALS.md](APPEALS.md).

## On a network (1.4.0)

* A punishment you issue applies on **every** server of the network, whether the player is online (on any server), offline, or logs in later.
* If a player you want to punish is not found by name, they have never joined any server of the network.
* A **jailed** player is moved to the jail server automatically and cannot move, build, fight, chat or use commands until the jail has them; releasing them (`/ap unjail`) works from any server and sends them back.
* If you see *"The database is unavailable right now. Nothing was changed."*, nothing was recorded: wait a minute and try again.
* If the jail server is down you are told *"Nobody was jailed"*; use another punishment for now.
